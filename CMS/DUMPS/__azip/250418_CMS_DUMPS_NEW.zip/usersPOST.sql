[
  {
    "username": "admina",
    "firstName": "Anna",
    "lastName": "Admin",
    "password": "jelszo123",
    "role": "Admin"
  },
  {
    "username": "adminb",
    "firstName": "Béla",
    "lastName": "Admin",
    "password": "jelszo123",
    "role": "Admin"
  },
  {
    "username": "jegykezeloa",
    "firstName": "Aladár",
    "lastName": "Jegykezelő",
    "password": "jelszo123",
    "role": "TicketAssistant"
  },
  {
    "username": "jegykezelob",
    "firstName": "Bogi",
    "lastName": "Jegykezelő",
    "password": "jelszo123",
    "role": "TicketAssistant"
  },
  {
    "username": "ettermesa",
    "firstName": "András",
    "lastName": "Éttermes",
    "password": "jelszo123",
    "role": "RestaurantAssistant"
  },
  {
    "username": "ettermesb",
    "firstName": "Bea",
    "lastName": "Éttermes",
    "password": "jelszo123",
    "role": "RestaurantAssistant"
  }
]
