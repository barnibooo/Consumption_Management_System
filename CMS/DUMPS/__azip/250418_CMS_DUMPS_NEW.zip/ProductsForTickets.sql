INSERT INTO Tickets (TicketName, Category, Description, ImagePath, Price)
VALUES
('Felnőtt Napijegy', 'Belépő', 'Egész napos belépő felnőttek részére.', '/img/tickets/felnott.jpg', 4500),
('Diák Napijegy', 'Belépő', 'Kedvezményes egész napos belépő diákok számára.', '/img/tickets/diak.jpg', 3500),
('Nyugdíjas Napijegy', 'Belépő', 'Kedvezményes egész napos belépő nyugdíjasok számára.', '/img/tickets/nyugdijas.jpg', 3500),
('Gyermek Napijegy', 'Belépő', 'Egész napos belépő 3-14 éves gyermekeknek.', '/img/tickets/gyermek.jpg', 2500)